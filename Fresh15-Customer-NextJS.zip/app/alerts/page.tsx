"use client";

import { Route } from "@/routes/alerts";

export default function Page() {
  return <Route.component />;
}